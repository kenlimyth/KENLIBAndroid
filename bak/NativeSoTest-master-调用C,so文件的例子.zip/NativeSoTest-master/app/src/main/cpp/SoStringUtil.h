#ifndef _SO_STRING_UTIL_H_
#define _SO_STRING_UTIL_H_

#include<iostream>
#include<stdlib.h>

using namespace std;


string getStringFromSoLibrary();

#endif