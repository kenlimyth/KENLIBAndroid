# Android - Jetpack - Demo
ROOM数据库+DataBinding+LiveData+ViewModel+Lifecycles
