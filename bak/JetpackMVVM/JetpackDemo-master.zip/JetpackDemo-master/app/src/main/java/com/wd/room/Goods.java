package com.wd.room;

import androidx.databinding.BaseObservable;

public class Goods extends BaseObservable {
    public int gid;
    public String name;
}
