package com.wd.room.activity;


import android.os.Bundle;

import com.wd.room.R;
import com.wd.room.databinding.ActivityLeftRightBinding;

public class LeftRightActivity extends BaseActivity<ActivityLeftRightBinding> {
    @Override
    protected void initView(Bundle savedInstanceState) {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_left_right;
    }
}
