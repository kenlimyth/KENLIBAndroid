package com.vc.wd.common.bean.shop;

/**
 * desc
 * author VcStrong
 * github VcStrong
 * date 2020/5/28 1:42 PM
 */
public class HomeList {
    CommodityList rxxp;
    CommodityList mlss;
    CommodityList pzsh;

    public CommodityList getRxxp() {
        return rxxp;
    }

    public void setRxxp(CommodityList rxxp) {
        this.rxxp = rxxp;
    }

    public CommodityList getMlss() {
        return mlss;
    }

    public void setMlss(CommodityList mlss) {
        this.mlss = mlss;
    }

    public CommodityList getPzsh() {
        return pzsh;
    }

    public void setPzsh(CommodityList pzsh) {
        this.pzsh = pzsh;
    }
}
