package com.vc.wd.common.core.http;

/**
  * desc 建议放到相关的module中，不建议在common包中写接口
  * author VcStrong
  * github VcStrong
  * date 2020/5/28 1:42 PM
  */
public interface IBaiduRequest {
}
