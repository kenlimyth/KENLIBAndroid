package com.vc.wd.main.vm;

import com.vc.wd.common.core.WDFragViewModel;
import com.vc.wd.main.request.IMainRequest;

public class TestViewModel extends WDFragViewModel<IMainRequest> {

}
