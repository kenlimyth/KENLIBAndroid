package com.vc.wd.im.activity;

import androidx.appcompat.app.AppCompatActivity;

public class ChatActivity extends AppCompatActivity {
}
